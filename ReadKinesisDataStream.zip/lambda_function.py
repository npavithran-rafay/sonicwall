import json, os, boto3
from datetime import datetime, timedelta

region = os.environ['region']

def add_value_to_DDB(ts,item,itemColName):
    
    dynamodb = boto3.resource('dynamodb', region)
    table = dynamodb.Table(os.environ['DDBtablename'])
    
    try:
        response = table.update_item(
            Key={
                'ts': ts
            },
            UpdateExpression="set {}=:a".format(itemColName),
            ExpressionAttributeValues={
                ':a': item
            }
        )
    except:
        print("Couldn't update table with {} - {}:{}".format(ts,itemColName,item))
    

def lambda_handler(event, context):
    ddb_client = boto3.client('dynamodb', region)
    try:
        response = ddb_client.create_table(
            AttributeDefinitions=[{'AttributeName': 'ts','AttributeType': 'S'}],
            TableName=os.environ['DDBtablename'],
            KeySchema=[{'AttributeName': 'ts','KeyType': 'HASH'}],
            ProvisionedThroughput={'ReadCapacityUnits': 5,'WriteCapacityUnits': 5}
            )
    except:
        print("Table already exists")
    
    dynamodb = boto3.resource('dynamodb', region)
    table = dynamodb.Table(os.environ['DDBtablename'])
    kinesis_client = boto3.client('kinesis', region)
    cloudwatch_client = boto3.client('cloudwatch', region)
    
    GetRecords_Bytes = []
    GetRecords_IAMS = []
    PutRecordsRecords = []
    GetRecordsRecords = []
    PutRecords_Bytes = []
    total = []
    
    response1 = cloudwatch_client.list_metrics(Namespace='AWS/Kinesis', MetricName='GetRecords.IteratorAgeMilliseconds', RecentlyActive='PT3H')
    response = cloudwatch_client.list_metrics(Namespace='AWS/Kinesis', RecentlyActive='PT3H')
    for i in response['Metrics']:
        for j in range(1):
            try:
                if i['Dimensions'][0]['Value'] == os.environ['kinesis_stream']:
                    if i['MetricName'] == 'GetRecords.Bytes':
                        GetRecords_Bytes.append(i)
                    if i['MetricName'] == 'GetRecords.IteratorAgeMilliseconds':
                        GetRecords_IAMS.append(i)
                    if i['MetricName'] == 'PutRecords.Records':
                        PutRecordsRecords.append(i)
                    if i['MetricName'] == 'GetRecords.Records':
                        GetRecordsRecords.append(i)
                    if i['MetricName'] == 'PutRecords.Bytes':
                        PutRecords_Bytes.append(i)
                
            except:
                error = 'Nothing'
    
    
    
    timenow = datetime.now()
    timeafter = timedelta(minutes=15)
    timestamps = {}
    
    GRR_response = {}
    GRB_response = {}
    IAM_response = {}
    PRR_response = {}
    PRB_response = {}
    
    
    # GetRecords.Bytes
    
    for i in GetRecords_Bytes:
        GRB_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Sum']
        )
    
    for i in range(len(GRB_response['Datapoints'])):
        ts = str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp()))
        try:
            response = table.put_item(Item={'ts': ts})
        except:
            print("Couldn't update table with {}".format(ts))
        
    for i in range(len(GRB_response['Datapoints'])):
        add_value_to_DDB(str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp())),str(GRB_response['Datapoints'][i]['Sum']),'GetRecords_Bytes')
        total.append(str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp())))
    
    
    # GetRecords.Records
    
    for i in GetRecordsRecords:
        GRR_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Sum']
        )
    
    for i in range(len(GRR_response['Datapoints'])):
        add_value_to_DDB(str(int(GRR_response['Datapoints'][i]['Timestamp'].timestamp())),str(GRR_response['Datapoints'][i]['Sum']),'GetRecords_Records')
   
        
    # GetRecords.IteratorAgeMilliseconds

    for i in GetRecords_IAMS:
        IAM_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Maximum'],
            Unit='Milliseconds'
        )
        
    for i in range(len(IAM_response['Datapoints'])):
        add_value_to_DDB(str(int(IAM_response['Datapoints'][i]['Timestamp'].timestamp())),str(IAM_response['Datapoints'][i]['Maximum']),'GetRecords_IteratorAgeMilliseconds')
        
        
    # PutRecords.Bytes
    
    for i in PutRecords_Bytes:
        PRB_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Sum']
        )
        
    for i in range(len(PRB_response['Datapoints'])):
        add_value_to_DDB(str(int(PRB_response['Datapoints'][i]['Timestamp'].timestamp())),str(PRB_response['Datapoints'][i]['Sum']),'PutRecords_Bytes')
        
        
    # PutRecords.Records
    
    for i in PutRecordsRecords:
        PRR_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Sum']
        )
    
    for i in range(len(PRR_response['Datapoints'])):
        add_value_to_DDB(str(int(PRR_response['Datapoints'][i]['Timestamp'].timestamp())),str(PRR_response['Datapoints'][i]['Sum']),'PutRecords_Records')
    
    print(total)
    return "Task Completed"