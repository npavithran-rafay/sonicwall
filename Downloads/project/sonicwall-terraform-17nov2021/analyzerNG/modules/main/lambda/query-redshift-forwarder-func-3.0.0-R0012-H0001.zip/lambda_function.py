import psycopg2, os, sys, json, time, boto3
from boto3.dynamodb.conditions import Key, Attr
from psycopg2.extras import RealDictCursor
from datetime import datetime

REDSHIFT_DATABASE = os.environ['REDSHIFT_DATABASE']
REDSHIFT_USER = os.environ['REDSHIFT_USER']
REDSHIFT_PASSWD = os.environ['REDSHIFT_PASSWD']
REDSHIFT_PORT = os.environ['REDSHIFT_PORT']
REDSHIFT_ENDPOINT = os.environ['REDSHIFT_ENDPOINT']
client = boto3.client('athena')


def athena_resp_to_json(resp):
        json_output = []
        meta_obj = {}
        colseq = []
        if len(resp['ResultSet']['Rows'])<=0:
                return None
        for data in resp['ResultSet']['Rows'][0]['Data']:
                colname = data['VarCharValue']
                colseq.append(colname)
                coltype = 'int'
                for meta in resp['ResultSet']['ResultSetMetadata']['ColumnInfo']:
                        if meta['Name'] == colname and meta['Type'] == 'varchar':
                                coltype = 'varchar'
                meta_obj[colname] = coltype
                    
        for row in resp['ResultSet']['Rows'][1:]:
                rowdata = {}
                for idx, data in enumerate(row['Data']):
                        row_colname = colseq[idx]
                        if meta_obj[row_colname] == 'int':
                                if 'VarCharValue' not in data.keys():
                                        rowdata[row_colname] = 0
                                else:
                                        rowdata[row_colname] = int(data['VarCharValue'])
                        else:
                                if 'VarCharValue' not in data.keys():
                                        rowdata[row_colname] = 'None'
                                else:
                                        rowdata[row_colname] = data['VarCharValue']
                           
                json_output.append(rowdata)
        
        return json_output

def query_data_from_athena(queryString, giveId = False, tformat = 'parquet', serialnum = None):
        _s = time.time()
        fstring = 'WITH (format = \'TEXTFILE\', field_delimiter = \',\')'
        if tformat == 'json':
                fstring = 'WITH (format = \'JSON\')'
        if tformat == 'parquet':
                fstring = 'WITH (format = \'Parquet\', parquet_compression = \'SNAPPY\', bucket_count=1, bucketed_by = ARRAY[\'serialnum\'])'
        
        query = client.start_query_execution(
            QueryString = queryString if not giveId else 'CREATE TABLE  tmp_{} {} AS '.format(serialnum, fstring) + queryString,
            QueryExecutionContext = {
                    'Database': os.environ['ATHENA_DATABASE']
            },
            ResultConfiguration={
            'OutputLocation': os.environ['ATHENA_OUTPUT_LOCATION']
            }
        )
        
        if giveId:
                return [{"exec-id": query['QueryExecutionId']}], 0, 200
        
        queryExec = None
        state = ''
        while  state != 'SUCCEEDED':
                queryExec = client.get_query_execution(QueryExecutionId=query['QueryExecutionId'])
                print(queryExec)
                state = queryExec['QueryExecution']['Status']['State']
        
        response = client.get_query_results(QueryExecutionId=query['QueryExecutionId'])
        return athena_resp_to_json(response), queryExec['QueryExecution']['Statistics']['DataScannedInBytes'], 200

def query_data_from_redshift(queryString):
        resp_data, statusCode = [{'message': 'aa gya'}], 200
        return resp_data, statusCode

def check_athena_exec_status(execId):
        queryExec = client.get_query_execution(QueryExecutionId=execId)
        status = queryExec['QueryExecution']['Status']['State']
        print('status for exec-id:{} is status:{}'.format(execId, queryExec['QueryExecution']))
        return [{'status': status}], 0, 200
        

def query_data_from_redshift(queryString):
        REDSHIFT_QUERY = "{} ".format(queryString)
	print(REDSHIFT_QUERY)
	_s = time.time()
        try:
                conn = psycopg2.connect(
                        dbname=REDSHIFT_DATABASE,
                        user=REDSHIFT_USER,
                        password=REDSHIFT_PASSWD,
                        port=REDSHIFT_PORT,
                        host=REDSHIFT_ENDPOINT)
        except Exception as e:
                print("Connection Issue: " + str(e))
                timeTaken, statusCode = time.time() - _s, 500
        try:
                cursor = conn.cursor(cursor_factory=RealDictCursor)
                cursor.execute(REDSHIFT_QUERY)
                output_data = cursor.fetchall()
                #output_data = '|'.join(map(lambda (idx, rw): str(idx+1) + ',' + ','.join(map(str, rw)), enumerate(records)))
                cursor.close()
                conn.close()
                timeTaken = time.time() - _s
                statusCode = 200
        except Exception as e:
                print("Execution Issue: " + str(e))
                timeTaken, statusCode = time.time() - _s, 500
        return output_data, statusCode

def lambda_handler(event, context):
        
        dataScanned = 0
        
        if 'athena' in event.keys() and type(event['athena']) == bool and event['athena']:
                serialnum = event['serialnum'] if 'serialnum' in event.keys() else None
                if 'exec-id' in event.keys() and event['exec-id']:
                        resp_data, dataScanned, statusCode = check_athena_exec_status(event['exec-id'])
                        if resp_data[0]['status'] and resp_data[0]['status'] in ['SUCCEEDED', 'FAILED']:
                                 query_data_from_athena('DROP TABLE IF EXISTS tmp_{}'.format(serialnum))
                        
                else:
                        queryString = event['queryString']
                        resp_data, dataScanned, statusCode = query_data_from_athena(queryString, tformat = event['format'] if 'format' in event.keys() else 'parquet', giveId = event['sch-report'] if 'sch-report' in event.keys() else False, serialnum = serialnum)
                        
                print(resp_data)

        else:
                queryString = event['queryString']
                resp_data, statusCode = query_data_from_redshift(queryString)
        print(resp_data)
        response = {
                'statusCode': statusCode,
                'dataScannedInBytes': dataScanned,
                'body': json.dumps(resp_data),
                }
        return response
