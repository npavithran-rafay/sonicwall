import json, boto3, os
from datetime import datetime, timedelta, timezone
from time import strftime


def lambda_handler(event, context):
    # TODO implement
    region = os.environ['region']
    emr_client = boto3.client('emr',region)
    lambda_client = boto3.client('lambda',region)
    s3_resource = boto3.resource('s3',region)
    s3_client = boto3.client('s3',region)
    athena_client = boto3.client('athena',region)
    secrets_client = boto3.client('secretsmanager',region)
    sns_client = boto3.client('sns',region)
    
    try:
        hr = {"us-west-2":-7,"eu-central-1":2,"ap-south-1":5.5}
        hours_added = timedelta(hours = hr[region])
    except:
        print("ERROR: Please set region! Currently using UTC!")
        hours_added = 0

    # datetime object containing current date and time
    now = datetime.now()
    now = now + hours_added
    # yyyymmdd
    dt_string = now.strftime("%Y%m%d")
    
    
    year = int(str(dt_string)[0:4])
    
    if (year % 4) == 0:
        if (year % 100) == 0:
            if (year % 400) == 0:
                days_in_a_year = 366
            else:
                days_in_a_year = 365
        else:
            days_in_a_year = 366
    else:
        days_in_a_year = 365
    
    enddate = str((now + timedelta(hours = 48)).strftime("%Y%m%d"))
    startdate_analytics =startdate = str((now - timedelta(days = 60)).strftime("%Y%m%d"))
    startdate_report = str((now - timedelta(days = days_in_a_year)).strftime("%Y%m%d"))
    
    #print(startdate)
    #print(enddate)
    dbname = os.environ['dbname']

    queries = ["DROP TABLE IF EXISTS "+dbname+".flowblocked",
    """
    CREATE EXTERNAL TABLE """+dbname+""".`flowblocked`(
  `timestamp` bigint, 
  `id` bigint, 
  `init_gw_mac` string, 
  `resp_gw_mac` string, 
  `init_addr` bigint, 
  `init_loc_id` bigint, 
  `resp_addr` bigint, 
  `resp_loc_id` bigint, 
  `init_remap_ip` bigint, 
  `resp_remap_ip` bigint, 
  `init_gw` bigint, 
  `resp_gw` bigint, 
  `init_iface` bigint, 
  `resp_iface` bigint, 
  `init_port` bigint, 
  `resp_port` bigint, 
  `init_remap_port` bigint, 
  `resp_remap_port` bigint, 
  `init_pkts` bigint, 
  `init_octets` bigint, 
  `resp_pkts` bigint, 
  `resp_octets` bigint, 
  `last_timestamp` bigint, 
  `flags` bigint, 
  `protocol` string, 
  `b_reason` bigint, 
  `botnet` bigint, 
  `sig_id` bigint, 
  `sig_name` string, 
  `gapp_id` bigint, 
  `intrusion_id` bigint, 
  `gintrusion_id` bigint, 
  `gav_id` bigint, 
  `ggav_id` bigint, 
  `aspy_id` bigint, 
  `gaspy_id` bigint, 
  `is_close` bigint, 
  `is_url` bigint, 
  `dpissl` bigint, 
  `state` bigint, 
  `user_auth` bigint, 
  `security_policy_id` bigint, 
  `app_rule_id` bigint, 
  `nat_policy_id` bigint, 
  `route_policy_id` bigint, 
  `decryption_policy_id` bigint, 
  `init_tos` bigint, 
  `resp_tos` bigint, 
  `init_vpn_policy_name` string, 
  `resp_vpn_policy_name` string, 
  `usr_name` string, 
  `gapp_sig_ids_1` bigint, 
  `gapp_sig_ids_2` bigint, 
  `gapp_sig_ids_3` bigint, 
  `gapp_sig_ids_4` bigint, 
  `gintrusion_sig_ids_1` bigint, 
  `gintrusion_sig_ids_2` bigint, 
  `gintrusion_sig_ids_3` bigint, 
  `gintrusion_sig_ids_4` bigint, 
  `senttime` bigint, 
  `app_id` bigint, 
  `app_name` string, 
  `cat_id` bigint, 
  `cat_name` string, 
  `gav_name` string, 
  `intrusion_name` string, 
  `aspy_name` string, 
  `prio_id` bigint, 
  `gav_priority` bigint, 
  `aspy_priority` bigint, 
  `tenantid` string, 
  `groupid` string, 
  `decryption_ssl_id` int, 
  `decryption_ssh_id` int, 
  `sdwan` int, 
  `threat_id` int, 
  `threat_type` string, 
  `threat_name` string, 
  `slot_id` int, 
  `risk` int, 
  `in_pri` int, 
  `out_pri` int)
PARTITIONED BY ( 
  `date` string, 
  `hour` string, 
  `serialnum` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
WITH SERDEPROPERTIES ( 
  'parquet.column.index.access'='false') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://"""+os.environ['logbucket']+"""/flowdata/'
TBLPROPERTIES (
  'projection.enabled'='true',
  'projection.date.interval'='1',
  'projection.date.range'='"""
  +
  startdate_analytics
  +
  ""","""
  +
  enddate
  +"""',
  'projection.date.type'='integer',
  'projection.hour.interval'='1',
  'projection.hour.range'='0,24',
  'projection.hour.type'='integer',
  'projection.serialnum.type'='injected',
  'storage.location.template'='s3://"""+os.environ['logbucket']+"""/flowdata/date=${date}/hour=${hour}/serialnum=${serialnum}')
    """
    ,
    "DROP TABLE IF EXISTS "+dbname+".flowdata",
    """
    CREATE EXTERNAL TABLE """+dbname+""".`flowdata`(
  `timestamp` bigint, 
  `id` bigint, 
  `init_gw_mac` string, 
  `resp_gw_mac` string, 
  `init_addr` bigint, 
  `init_loc_id` bigint, 
  `resp_addr` bigint, 
  `resp_loc_id` bigint, 
  `init_remap_ip` bigint, 
  `resp_remap_ip` bigint, 
  `init_gw` bigint, 
  `resp_gw` bigint, 
  `init_iface` bigint, 
  `resp_iface` bigint, 
  `init_port` bigint, 
  `resp_port` bigint, 
  `init_remap_port` bigint, 
  `resp_remap_port` bigint, 
  `init_pkts` bigint, 
  `init_octets` bigint, 
  `resp_pkts` bigint, 
  `resp_octets` bigint, 
  `last_timestamp` bigint, 
  `flags` bigint, 
  `protocol` string, 
  `b_reason` bigint, 
  `botnet` bigint, 
  `sig_id` bigint, 
  `sig_name` string, 
  `gapp_id` bigint, 
  `intrusion_id` bigint, 
  `gintrusion_id` bigint, 
  `gav_id` bigint, 
  `ggav_id` bigint, 
  `aspy_id` bigint, 
  `gaspy_id` bigint, 
  `is_close` bigint, 
  `is_url` bigint, 
  `dpissl` bigint, 
  `state` bigint, 
  `user_auth` bigint, 
  `security_policy_id` bigint, 
  `app_rule_id` bigint, 
  `nat_policy_id` bigint, 
  `route_policy_id` bigint, 
  `decryption_policy_id` bigint, 
  `init_tos` bigint, 
  `resp_tos` bigint, 
  `init_vpn_policy_name` string, 
  `resp_vpn_policy_name` string, 
  `usr_name` string, 
  `gapp_sig_ids_1` bigint, 
  `gapp_sig_ids_2` bigint, 
  `gapp_sig_ids_3` bigint, 
  `gapp_sig_ids_4` bigint, 
  `gintrusion_sig_ids_1` bigint, 
  `gintrusion_sig_ids_2` bigint, 
  `gintrusion_sig_ids_3` bigint, 
  `gintrusion_sig_ids_4` bigint, 
  `senttime` bigint, 
  `app_id` bigint, 
  `app_name` string, 
  `cat_id` bigint, 
  `cat_name` string, 
  `gav_name` string, 
  `intrusion_name` string, 
  `aspy_name` string, 
  `prio_id` bigint, 
  `gav_priority` bigint, 
  `aspy_priority` bigint, 
  `tenantid` string, 
  `groupid` string, 
  `decryption_ssl_id` int, 
  `decryption_ssh_id` int, 
  `sdwan` int, 
  `threat_id` int, 
  `threat_type` string, 
  `threat_name` string, 
  `slot_id` int, 
  `risk` int, 
  `in_pri` int, 
  `out_pri` int)
PARTITIONED BY ( 
  `date` string, 
  `hour` string, 
  `serialnum` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
WITH SERDEPROPERTIES ( 
  'parquet.column.index.access'='false') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://"""+os.environ['logbucket']+"""/flowdata/'
TBLPROPERTIES (
  'projection.enabled'='true',
  'projection.date.interval'='1',
  'projection.date.range'='"""
  +
  startdate_report
  +
  ""","""
  +
  enddate
  +"""',
  'projection.date.type'='integer',
  'projection.hour.interval'='1',
  'projection.hour.range'='0,24',
  'projection.hour.type'='integer',
  'projection.serialnum.type'='injected',
  'storage.location.template'='s3://"""+os.environ['logbucket']+"""/flowdata/date=${date}/hour=${hour}/serialnum=${serialnum}')
    """
    ,
    "DROP TABLE IF EXISTS "+dbname+".flowthreat",
    """
    CREATE EXTERNAL TABLE """+dbname+""".`flowthreat`(
  `timestamp` bigint, 
  `id` bigint, 
  `init_gw_mac` string, 
  `resp_gw_mac` string, 
  `init_addr` bigint, 
  `init_loc_id` bigint, 
  `resp_addr` bigint, 
  `resp_loc_id` bigint, 
  `init_remap_ip` bigint, 
  `resp_remap_ip` bigint, 
  `init_gw` bigint, 
  `resp_gw` bigint, 
  `init_iface` bigint, 
  `resp_iface` bigint, 
  `init_port` bigint, 
  `resp_port` bigint, 
  `init_remap_port` bigint, 
  `resp_remap_port` bigint, 
  `init_pkts` bigint, 
  `init_octets` bigint, 
  `resp_pkts` bigint, 
  `resp_octets` bigint, 
  `last_timestamp` bigint, 
  `flags` bigint, 
  `protocol` string, 
  `b_reason` bigint, 
  `botnet` bigint, 
  `sig_id` bigint, 
  `sig_name` string, 
  `gapp_id` bigint, 
  `intrusion_id` bigint, 
  `gintrusion_id` bigint, 
  `gav_id` bigint, 
  `ggav_id` bigint, 
  `aspy_id` bigint, 
  `gaspy_id` bigint, 
  `is_close` bigint, 
  `is_url` bigint, 
  `dpissl` bigint, 
  `state` bigint, 
  `user_auth` bigint, 
  `security_policy_id` bigint, 
  `app_rule_id` bigint, 
  `nat_policy_id` bigint, 
  `route_policy_id` bigint, 
  `decryption_policy_id` bigint, 
  `init_tos` bigint, 
  `resp_tos` bigint, 
  `init_vpn_policy_name` string, 
  `resp_vpn_policy_name` string, 
  `usr_name` string, 
  `gapp_sig_ids_1` bigint, 
  `gapp_sig_ids_2` bigint, 
  `gapp_sig_ids_3` bigint, 
  `gapp_sig_ids_4` bigint, 
  `gintrusion_sig_ids_1` bigint, 
  `gintrusion_sig_ids_2` bigint, 
  `gintrusion_sig_ids_3` bigint, 
  `gintrusion_sig_ids_4` bigint, 
  `senttime` bigint, 
  `app_id` bigint, 
  `app_name` string, 
  `cat_id` bigint, 
  `cat_name` string, 
  `gav_name` string, 
  `intrusion_name` string, 
  `aspy_name` string, 
  `prio_id` bigint, 
  `gav_priority` bigint, 
  `aspy_priority` bigint, 
  `tenantid` string, 
  `groupid` string, 
  `decryption_ssl_id` int, 
  `decryption_ssh_id` int, 
  `sdwan` int, 
  `threat_id` int, 
  `threat_type` string, 
  `threat_name` string, 
  `slot_id` int, 
  `risk` int, 
  `in_pri` int, 
  `out_pri` int)
PARTITIONED BY ( 
  `date` string, 
  `hour` string, 
  `serialnum` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
WITH SERDEPROPERTIES ( 
  'parquet.column.index.access'='false') 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://"""+os.environ['logbucket']+"""/flowdata/'
TBLPROPERTIES (
  'projection.enabled'='true',
  'projection.date.interval'='1',
  'projection.date.range'='"""
  +
  startdate_analytics
  +
  ""","""
  +
  enddate
  +"""',
  'projection.date.type'='integer',
  'projection.hour.interval'='1',
  'projection.hour.range'='0,24',
  'projection.hour.type'='integer',
  'projection.serialnum.type'='injected',
  'storage.location.template'='s3://"""+os.environ['logbucket']+"""/flowdata/date=${date}/hour=${hour}/serialnum=${serialnum}')
    """
    ,
    "DROP TABLE IF EXISTS "+dbname+".reportdata_proj",
    """
    CREATE EXTERNAL TABLE """+dbname+""".`reportdata_proj`(
  `rp_index` bigint, 
  `elem_id` string, 
  `elem_name` string, 
  `sessions` bigint, 
  `init_octets` bigint, 
  `resp_octets` bigint, 
  `af_blocked` bigint, 
  `acr_blocked` bigint, 
  `cfs_blocked` bigint, 
  `threats_blocked` bigint, 
  `total_blocked` bigint, 
  `geo_blocked` bigint, 
  `bot_blocked` bigint, 
  `intrusion_id` bigint, 
  `aspy_id` bigint, 
  `gav_id` bigint, 
  `init_pkts` bigint, 
  `resp_pkts` bigint)
PARTITIONED BY ( 
  `tabletype` string, 
  `type` string, 
  `date` string, 
  `serialnum` string)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
LOCATION
  's3://"""+os.environ['logbucket']+"""/reportdata/'
TBLPROPERTIES (
  'projection.enabled'='true',
  'projection.tabletype.interval'='1',
  'projection.tabletype.range'='0,24',
  'projection.tabletype.type'='integer',
  'projection.type.interval'='1',
  'projection.type.range'='0,5',
  'projection.type.type'='integer',
  'projection.date.interval'='1',
  'projection.date.range'='"""
  +
  startdate_report
  +
  ""","""
  +
  enddate
  +"""',
  'projection.date.type'='integer',
  'projection.serialnum.type'='injected',
  'storage.location.template'='s3://"""+os.environ['logbucket']+"""/reportdata/tableType=${tabletype}/type=${type}/date=${date}/serialnum=${serialnum}')
    """]
    
    
    for i in range(len(queries)):
        response_execute = athena_client.start_query_execution(QueryString=queries[i],WorkGroup=os.environ['WorkGroup_Name'])
        flag = 1
        while flag:
          response_get = athena_client.get_query_execution(QueryExecutionId=response_execute['QueryExecutionId'])
          if response_get['QueryExecution']['Status']['State'] == 'SUCCEEDED':
            flag = 0