import json,os,boto3

def restart(region,bucket,lambda_client,events_client,cloudwatch_rule_name,cluster_id,dynamo_tables,new_cluster_id):
    
    #Existing Rule
    try:
        print("3")
        event_response = events_client.describe_rule(Name=cloudwatch_rule_name)
        
        event_arn = lambda_client.get_function(FunctionName=os.environ['lambda_execute_name'])
        event_arn = event_arn['Configuration']['FunctionArn']
        
        response = events_client.list_targets_by_rule(Rule=event_response['Name'])
        response = events_client.remove_targets(Rule=event_response['Name'],Ids=[response['Targets'][0]['Id']])
        response = events_client.delete_rule(Name=event_response['Name'])
        
        event_pattern="{\"source\":[\"aws.emr\"],\"detail-type\":[\"EMR Cluster State Change\"],\"detail\":{\"state\":[\"RUNNING\"],\"clusterId\":[\""+new_cluster_id+"\"]}}"
        
        response = events_client.put_rule(Name=event_response['Name'],EventPattern=event_pattern,State='ENABLED')
        
        ConstantJSON = "{     \"emr_cluster_id\":\""+cluster_id+"\",     \"dynamo_tables\":\""+dynamo_tables+"\",     \"cloudwatch_rule_name\":\""+cloudwatch_rule_name+"\" }"
        response = events_client.put_targets(Rule=cloudwatch_rule_name,Targets=[{'Id': '1','Arn': event_arn,'Input':ConstantJSON}])
        return response
    
    #New Rule
    except:
        print('Error modifying EventBridge rule. Will create new rule.')
        
        event_pattern="{\"source\":[\"aws.emr\"],\"detail-type\":[\"EMR Cluster State Change\"],\"detail\":{\"state\":[\"RUNNING\"],\"clusterId\":[\""+new_cluster_id+"\"]}}"
        
        
        try:
            response = events_client.put_rule(Name=cloudwatch_rule_name,EventPattern=event_pattern,State='ENABLED')
        except:
            print("Error creating rule")
        
        try:
            event_response = events_client.describe_rule(Name=cloudwatch_rule_name)
            
            event_arn = lambda_client.get_function(FunctionName=os.environ['lambda_execute_name'])
            event_arn = event_arn['Configuration']['FunctionArn']
            print(event_arn)
            
            ConstantJSON = "{     \"emr_cluster_id\":\""+cluster_id+"\",     \"dynamo_tables\":\""+dynamo_tables+"\",     \"cloudwatch_rule_name\":\""+cloudwatch_rule_name+"\" }"
            response = events_client.put_targets(Rule=cloudwatch_rule_name,Targets=[{'Id': '1','Arn': event_arn,'Input':ConstantJSON},])
            
            
        except:
            print("Error adding target")
        
        
        
def lambda_handler(event, context):
    # TODO implement
    
    region = os.environ['region']
    bucket = os.environ['bucket_name']
    
    lambda_client = boto3.client('lambda',region)
    events_client = boto3.client('events',region)
    
    applicationName = event['appName']
    
    try:
        tag_response = lambda_client.get_function(FunctionName=os.environ['lambda_name'])
    except:
        print("Error: Tag value not retrieved")
    
    if applicationName == 'logparser':
        #Do Something LogParser
        print("inside logparser")
        try:
            restart(region,bucket,lambda_client,events_client,os.environ['cloudwatch_rule_name_logparser'],tag_response['Tags']['cluster_id_logparser'],tag_response['Tags']['dynamo_tables_logparser'],tag_response['Tags']['new_cluster_id_logparser'])
        except:
            print("Error LogParser")
        
    elif applicationName == 'logprocessor':
        #Do Something LogProcessor
        try:
            restart(region,bucket,lambda_client,events_client,os.environ['cloudwatch_rule_name_logprocessor'],tag_response['Tags']['cluster_id_logprocessor'],tag_response['Tags']['dynamo_tables_logprocessor'],tag_response['Tags']['new_cluster_id_logprocessor'])
        except:
            print("Error LogProcessor")
    else:
        print("Error in applicationName called: {}".format(applicationName))