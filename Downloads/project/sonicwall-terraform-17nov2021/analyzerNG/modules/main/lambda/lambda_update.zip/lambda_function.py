import json,boto3,os

def lambda_handler(event, context):
    # TODO implement
    # Add region and bucket
    # Rename Lambda Names in Line 10
    region = os.environ['region']
    bucket_name = os.environ['bucket_name']
    lambda_client = boto3.client('lambda',region)
    lambda_names = ["logProcessor","logProcessorWeb","logProcessorBucket"]
    
    lambda_functions = ["lambdas/logProcessor.zip","lambdas/logProcessorWeb.zip","lambdas/logProcessorBucket.zip"]
    
    for i in range(len(lambda_functions)):
        try:
            response = lambda_client.update_function_code(FunctionName=lambda_names[i],S3Bucket=bucket_name,S3Key=lambda_functions[i],Publish=True)
        except:
            print("Error")
    
    return 1