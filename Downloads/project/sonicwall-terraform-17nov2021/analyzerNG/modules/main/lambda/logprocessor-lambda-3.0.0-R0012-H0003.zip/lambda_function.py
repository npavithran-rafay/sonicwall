import boto3,json,os
from datetime import datetime

def lambda_handler(event, context):
    # TODO implement
    connection = boto3.client('emr',region_name=os.environ['region'])
    s3 = boto3.resource('s3',os.environ['region'])
    s3_client = boto3.client('s3',os.environ['region'])
    dynamo_client = boto3.client('dynamodb',os.environ['region'])
    lambda_client = boto3.client('lambda',os.environ['region'])
    
    bucket_name = os.environ['bucket_name']
    config_filename = os.environ['config_filename']
    
    result = s3_client.get_object(Bucket=bucket_name, Key=config_filename) 
    text = result["Body"].read().decode()
    json_data = json.loads(text)
    step_command=[]
    
    for key, value in json_data['common'].items():
        step_command.append(key)
        step_command.append(value)
    for key, value in json_data['logProcessor'].items():
        if key == '--conf':
            for i in value:
                step_command.append(key)
                step_command.append(i)
        else:
            step_command.append(key)
            step_command.append(value)
            
    #We are trying to remove the key for the last item where we call the jar: 'jar_file_location'
    del step_command[-2]
    
    #Running the EMR Cluster

    cluster_id = connection.run_job_flow(
        Name=json_data['logProcessorEmrDetails']['Name'],
        LogUri='s3://'+bucket_name+'/logs/',
        ReleaseLabel=json_data['logProcessorEmrDetails']['ReleaseLabel'],
        Applications=json_data['logProcessorEmrDetails']['Applications'],
        VisibleToAllUsers=True,
        JobFlowRole=json_data['logProcessorEmrDetails']['JobFlowRole'],
        ServiceRole=json_data['logProcessorEmrDetails']['ServiceRole'],
        ScaleDownBehavior=json_data['logProcessorEmrDetails']['ScaleDownBehavior'],
        EbsRootVolumeSize=json_data['logProcessorEmrDetails']['EbsRootVolumeSize'],
        Tags=json_data['logProcessorTags'],
        Instances=json_data['logProcessorInstances']['Instances'],
        Steps = [
            {
                'Name': 'Setup Hadoop Debugging',
                'ActionOnFailure': 'TERMINATE_CLUSTER',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                'Args': ['state-pusher-script']
                }
            },
        ]
    )
    
    step_function_argument = ['spark-submit']
    step_function_argument+=step_command
    
    step = {
        'Name': 'jar-step',
        'ActionOnFailure': 'TERMINATE_CLUSTER',
        'HadoopJarStep': {
                'Jar': 'command-runner.jar',
                'Args': step_function_argument
        }
    }
    action = connection.add_job_flow_steps(JobFlowId=cluster_id['JobFlowId'], Steps=[step])

    if json_data['logProcessorManagedScalingPolicy']['autoscalingFlag']=='on':
        Cluster_ID=cluster_id['JobFlowId']
        response = connection.put_managed_scaling_policy(
            ClusterId=Cluster_ID,
            ManagedScalingPolicy={'ComputeLimits': json_data['logProcessorManagedScalingPolicy']['ComputeLimits']}
        )
    print ('Cluster id: ', cluster_id['JobFlowId'])
    
    new_cluster_id=cluster_id['JobFlowId']
    '''
    for i in json_data['logProcessorDynamoDBTables']:
        try:
            table_delete_response = dynamo_client.delete_table(TableName=i)
            print(table_delete_response)
        except:
            print("No tables to delete")
    '''
    dynamo_tables=""
    for i in json_data['logProcessorDynamoDBTables']:
        dynamo_tables=dynamo_tables+i+"="
    dynamo_tables=dynamo_tables[:-1]
    
    
    #change tag values
    restart_lambda_name = os.environ['restart_lambda_name']
    try:
        event_arn = lambda_client.get_function(FunctionName=restart_lambda_name)
        event_arn = event_arn['Configuration']['FunctionArn']
        response = lambda_client.untag_resource(Resource=event_arn,TagKeys=['cluster_id_logprocessor','dynamo_tables_logprocessor','new_cluster_id_logprocessor'])
        try:
            tag_response = lambda_client.get_function(FunctionName=os.environ['lambda_name'])
        except:
            print("Error: Tag value not retrieved")
        response = lambda_client.tag_resource(Resource=event_arn,Tags={'cluster_id_logprocessor': tag_response['Tags']['cluster_id']})
        response = lambda_client.tag_resource(Resource=event_arn,Tags={'dynamo_tables_logprocessor': dynamo_tables})
        response = lambda_client.tag_resource(Resource=event_arn,Tags={'new_cluster_id_logprocessor': new_cluster_id})
    except:
        print("can't utag/tag resource")
        
    try:
        lambda_client.invoke(FunctionName=restart_lambda_name,InvocationType='Event',Payload='{"appName":"logprocessor"}')
    except:
        print("cannot invoke lambda")