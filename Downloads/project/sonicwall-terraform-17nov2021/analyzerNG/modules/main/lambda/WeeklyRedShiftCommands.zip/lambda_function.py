import boto3
import os
import ast
from datetime import datetime, timedelta


# boto3 modules
region = os.environ['region']
secrets_client = boto3.client('secretsmanager',region)
redshift_client = boto3.client('redshift-data',region)
sns_client = boto3.client('sns',region)

def get_response(redshiftQueryId):
    # Fetch response of Redshift query using id value
    try:
        try:
            query_response = redshift_client.get_statement_result(Id=redshiftQueryId)
            return query_response['Records']
        except:
            return 'RunningQuery'
    except:
        print("Can't retrieve value")

def run_redshift_query(sql):
    
    # Secrets Manager
    Secret_Names_Secret_Id = os.environ['Secret_Names']
    Secret_Names_response = secrets_client.get_secret_value(SecretId = Secret_Names_Secret_Id)
    Secret_Names_accessKey = ast.literal_eval(Secret_Names_response['SecretString'])
    Redshift_Secret_Id = Secret_Names_accessKey['Redshift_Secret']
    Redshift_response = secrets_client.get_secret_value(SecretId = Redshift_Secret_Id)
    Redshift_accessKey = ast.literal_eval(Redshift_response['SecretString'])
    
    try:
        response = redshift_client.execute_statement(
            ClusterIdentifier=str(Redshift_accessKey['REDSHIFT_ENDPOINT']).split('.')[0],
            Sql=sql,
            Database=str(Redshift_accessKey['REDSHIFT_DBNAME']),
            DbUser=os.environ['Redshift_Admin_User']
        )
    except:
        return "ERROR: Unable to run query"
    
    print(response['Id'])
    
    try:
        check_resp = get_response(response['Id'])
        while(check_resp == 'RunningQuery'):
            check_resp = get_response(response['Id'])
        
        return check_resp
    except:
        print("Exception")
        return "Error"


def processing(redshift_query_response,query_num,header):
    
    
    temp1=[]
    temp1.append(header)
    for i in redshift_query_response:
        temp2=[]
        for j in i:
            for k,v in j.items():
                temp2.append(str(v))
        temp1.append(temp2)
    
    len_list = [len(element) for i in temp1 for element in i]
    output = ""
    for i in temp1:
        i = ",".join(element for element in i)
        output = output + i + "\n"
    
    
    return output

def send_email(email_content):
    
    output = ""
    for i in range(len(email_content)):
        if i>0:
            output = output + "\n\n" + email_content[i]
        else:
            output = output + email_content[i]
    
    try:
        response = sns_client.publish(
            TopicArn=os.environ['topicA'],
            Message='{}'.format(output),
            Subject='RedShift Query'),

    except:
        print("Couldn't email redshift response")


def lambda_handler(event, context):
    # Prepare and run redshift query
    # datetime object containing current date and time
    now = datetime.now()
    yesterday = now - timedelta(days=1)
    # yyyymmdd
    dt_string1 = now.strftime("%Y%m%d")
    dt_string = yesterday.strftime("%Y%m%d")
    year1 = str(dt_string1)[0:4]
    year= str(dt_string)[0:4]
    month = str(int(str(dt_string)[4:6]))
    day = str(int(str(dt_string)[6:]))
    
    sql = ["SELECT \"table\", size, tbl_rows, unsorted FROM SVV_TABLE_INFO where \"table\" like 'flowdata_"+year1+"_%'" , "select serialnum, count(id) from flowdata_"+year+"_"+month+"_"+day+" group by serialnum"]
    header = [["table","size","tbl_rows","unsorted"],["serialnum","count(ID)"]]

    email_content = []
    for query_num in range(len(sql)):
        redshift_query_response = run_redshift_query(sql[query_num])
        processed_data = processing(redshift_query_response,query_num+1,header[query_num])
        email_content.append(processed_data)
    send_email(email_content)
    
    