import json,boto3,os,ast

def lambda_handler(event, context):
    # TODO implement
    L=[]
    config_filename = os.environ['config_filename']
    region = os.environ['region']
    
    lambda_client = boto3.client('lambda',region)
    s3_resource = boto3.resource('s3',region)
    s3_client = boto3.client('s3',region)
    secrets_client = boto3.client('secretsmanager',region)
    
    Secret_Names_Secret_Id = os.environ['Secret_Names']
    Secret_Names_response = secrets_client.get_secret_value(SecretId = Secret_Names_Secret_Id)
    Secret_Names_accessKey = ast.literal_eval(Secret_Names_response['SecretString'])
    
    EMRDetails_Secret_Id = Secret_Names_accessKey['EMRDetails']
    EMRDetails_response = secrets_client.get_secret_value(SecretId = EMRDetails_Secret_Id)
    EMRDetails_accessKey = ast.literal_eval(EMRDetails_response['SecretString'])
    
    CommonDetails_Secret_Id = Secret_Names_accessKey['EMR_Secret']
    CommonDetails_response = secrets_client.get_secret_value(SecretId = CommonDetails_Secret_Id)
    CommonDetails_accessKey = ast.literal_eval(CommonDetails_response['SecretString'])
    
    Tags_Secret_Id = Secret_Names_accessKey['Tags']
    Tags_response = secrets_client.get_secret_value(SecretId = Tags_Secret_Id)
    TAGS = ast.literal_eval(Tags_response['SecretString'])
    
    bucket_name = EMRDetails_accessKey['bucket_name']
    
    result = s3_client.get_object(Bucket=bucket_name, Key=config_filename) 
    text = result["Body"].read().decode()
    
    for i in Secret_Names_accessKey.keys():
        rep_text = '<'+i+'>'
        if rep_text in text:
            try:
                text = text.replace(rep_text,Secret_Names_accessKey[i])
            except:
                print("Error Replacing Secret_Names")
                
                
    text = text.replace('<Secret_Names>',str(Secret_Names_Secret_Id))
    text = text.replace('<KINESIS_STREAM_REGION>',str(region))
    
    text = text.replace('<ATHENA_WORKGROUP_PATH_2>',str(CommonDetails_accessKey['ATHENA_WORKGROUP_PATH_2']))
    text = text.replace('<ATHENA_WORKGROUP_NAME_2>',str(CommonDetails_accessKey['ATHENA_WORKGROUP_NAME_2']))
    text = text.replace('<ATHENA_DBNAME>',str(CommonDetails_accessKey['ATHENA_DBNAME']))
    
    json_data = json.loads(text)
    
    Lambda_names = []
    for i in json_data.keys():
        
        more_tags = 0
        
        if i == 'logProcessor':
            i_new= EMRDetails_accessKey['NamelogProcessor']
        elif i == 'logProcessorWeb':
            i_new= EMRDetails_accessKey['NamelogProcessorWeb']
        elif i == 'logProcessorBucket':
            i_new= EMRDetails_accessKey['NamelogProcessorBucket']
        elif i == 'eventBridge-stepFunction-cease':
            i_new= EMRDetails_accessKey['NameEventBridgeCease']
            add_tags = {"count_stepFail_logprocessor": "0","count_stepFail_logprocessorweb": "0"}
            more_tags=1
        elif i == 'redshiftRestartEMR':
            i_new= EMRDetails_accessKey['NameRedshiftRestart']
        elif i == 'realtimereport-lambda':
            i_new= EMRDetails_accessKey['NameRTR']
        elif i == 'DeleteValues_DynamoDB_KStreamState_LPB':
            i_new= EMRDetails_accessKey['NameDeleteValues_DynamoDB_KStreamState_LPB']
        elif i == 'Setup':
            i_new= EMRDetails_accessKey['NameSetup']
        else:
            print("No change for: {}".format(i))
            i_new = i
        
        try:
            response = lambda_client.delete_function(
                FunctionName=i_new
                )
            print("Removed: {}".format(i))
        except:
            print("{} doesn't exist.".format(i))
        
        if more_tags == 1:
            new_TAGS = TAGS
            new_TAGS.update(add_tags)
            try:
                response = lambda_client.create_function(
                    FunctionName=i_new,
                    Runtime=json_data[i]['Runtime'],
                    Role=EMRDetails_accessKey['IAM_ARN'],
                    Handler=json_data[i]['Handler'],
                    Code={
                        'S3Bucket': EMRDetails_accessKey['bucket_name'],
                        'S3Key': json_data[i]['S3Key']
                    },
                    Description=json_data[i]['Description'],
                    Timeout=10,
                    Publish=True,
                    Environment=json_data[i]['Environment'],
                    Tags=new_TAGS
                )
                print("Created: {}".format(i))
                L.append(i)
            except:
                print("Error creating: {}".format(i))
        else:
            try:
                response = lambda_client.create_function(
                    FunctionName=i_new,
                    Runtime=json_data[i]['Runtime'],
                    Role=EMRDetails_accessKey['IAM_ARN'],
                    Handler=json_data[i]['Handler'],
                    Code={
                        'S3Bucket': EMRDetails_accessKey['bucket_name'],
                        'S3Key': json_data[i]['S3Key']
                    },
                    Description=json_data[i]['Description'],
                    Timeout=10,
                    Publish=True,
                    Environment=json_data[i]['Environment'],
                    Tags=TAGS
                )
                print("Created: {}".format(i))
                L.append(i)
            except:
                print("Error creating: {}".format(i))
    print(L)
    #lambda_client.invoke(FunctionName=EMRDetails_accessKey['NameSetup'])