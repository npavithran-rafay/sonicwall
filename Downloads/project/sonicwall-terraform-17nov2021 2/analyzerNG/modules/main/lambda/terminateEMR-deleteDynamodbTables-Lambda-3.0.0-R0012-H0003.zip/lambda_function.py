import json,os,boto3

def lambda_handler(event, context):
    # TODO implement
    emr_client = boto3.client('emr',os.environ['region'])
    events_client = boto3.client('events',os.environ['region'])
    dynamo_client = boto3.client('dynamodb',os.environ['region'])
    lambda_client = boto3.client('lambda',os.environ['region'])
    
    cluster_id = event['emr_cluster_id']
    dynamo_tables = event['dynamo_tables']
    eventbridge_rule = event['cloudwatch_rule_name']
    
    try:
        dynamo_tables=dynamo_tables.split('=')
    except:
        print("Error tables")
    print(dynamo_tables)
    #terminate cluster
    try:
        response = emr_client.terminate_job_flows(JobFlowIds=[cluster_id])
        print(response)
    except:
        print("Cluster unable to terminate")
        
    #delete tables
    for i in dynamo_tables:
        #delete
        try:
            table_delete_response = dynamo_client.delete_table(TableName=i)
            print(table_delete_response)
        except:
            print("No tables to delete")
    
    #disable EventBridge rule
    try:
        response = events_client.disable_rule(Name=eventbridge_rule)
    except:
        print("Error disable rule")
        
    return "Task Completed"