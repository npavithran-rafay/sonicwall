import os,json,boto3
from datetime import datetime

def get_ts():
        d = datetime.utcnow()
        date=datetime.strftime(d,'%Y%m%d')
        hour=datetime.strftime(d,'%H')
        return (date,hour)

def getCount(bucket,prefix,date,hour,s3_client):
        filePrefix="{}/date={}/hour={}/".format(prefix,date,hour)
        objs = s3_client.list_objects_v2(Bucket=bucket,Prefix=filePrefix,MaxKeys=5)
        fileCount = objs['KeyCount']
        print("Count of objects in date={} and hour={} is {}".format(date,hour,fileCount))
        return fileCount

def set_tag(function_arn,tag_key,value,lambda_client):
    untag = lambda_client.untag_resource(Resource=str(function_arn),TagKeys=[str(tag_key)])
    tag = lambda_client.tag_resource(Resource=str(function_arn),Tags={str(tag_key): str(value)})

def lambda_handler(event, context):
    # TODO implement
    emr_cluster_name=event['emr_cluster_restart_name']
    lambda_name=event['lambda_function_name']
    
    region = os.environ['region']
    bucket = os.environ['bucket_name']
    prefix = 'flowdata'
    
    lambda_client = boto3.client('lambda',region)
    s3_client = boto3.client('s3',region)
    emr_client = boto3.client('emr',region)
    s3_resource = boto3.resource('s3',region)
    
    new_run_response=''
    clusterid=''
    restart_emr = False
    
    date,hour = get_ts()
    hour=int(hour)
    
    object_count = int(getCount(bucket,prefix,date,hour,s3_client))
    
    response = lambda_client.get_function(FunctionName=os.environ['lambda_name'])

    if object_count!=0:
        if response['Tags']['p1']!='999':
            set_tag(response['Configuration']['FunctionArn'],'p1',str(999),lambda_client)
            if response['Tags']['p2']!='999':
                set_tag(response['Configuration']['FunctionArn'],'p2',str(999),lambda_client)
    else:
        if response['Tags']['p1']=='999':
            set_tag(response['Configuration']['FunctionArn'],'p1',str(object_count),lambda_client)
        else:
            if response['Tags']['p2']=='999':
                set_tag(response['Configuration']['FunctionArn'],'p2',str(object_count),lambda_client)
            else:
                print("Go and restart emr")
                print("p1:",response['Tags']['p1'])
                print("p2:",response['Tags']['p2'])
                print("object_count:",object_count)
                
                restart_emr = True
                
                set_tag(response['Configuration']['FunctionArn'],'p1',str(999),lambda_client)
                set_tag(response['Configuration']['FunctionArn'],'p2',str(999),lambda_client)

    try:
        running_clusters = emr_client.list_clusters(ClusterStates=['RUNNING','STARTING'])
        for i in range(len(running_clusters['Clusters'])):
            if running_clusters['Clusters'][i]['Name']==emr_cluster_name:
                clusterid=running_clusters['Clusters'][i]['Id']
    except:
        clusterid=''
    
    if clusterid!='':
        try:
            emrcluster = emr_client.describe_cluster(ClusterId=clusterid)
            if restart_emr==True:
                try:
                    emr_client.terminate_job_flows(JobFlowIds=[clusterid])
                    lambda_client.invoke(FunctionName=lambda_name)
                    new_run_response = "Cluster restarted required: previous 2 object count were: {} & {}".format(response['Tags']['p1'],response['Tags']['p1'])
                    print(new_run_response)
                    print("ClusterId: ",clusterid)
                except:
                    print("Error restarting cluster")
            else:
                print("No restart required. Cluster {} running HEALTHY".format(clusterid))
            
        except:
            print("Error: describe_cluster")
   
    else:
        try:
            lambda_client.invoke(FunctionName=lambda_name)
            new_run_response = "No emr clusters were running but a new a cluster has been started"
        except:
            print("Error invoking new cluster")