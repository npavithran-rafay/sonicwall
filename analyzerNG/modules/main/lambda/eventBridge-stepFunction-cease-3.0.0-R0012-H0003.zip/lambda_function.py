import json,os,boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # TODO implement
    emr_name = event['emr_name']
    #emr_name = "logparser"
    
    region = os.environ['region']
    event_arn = os.environ['arn']
    
    lambda_client = boto3.client('lambda',region)
    events_client = boto3.client('events',region)
    ses_client = boto3.client('ses',region)
    
    try:
        tag_response = lambda_client.get_function(FunctionName=os.environ['lambda_name'])
    except:
        print("Error: Tag values not retrieved")
    
    if emr_name == 'logparser':
        count = tag_response['Tags']['count_stepFail_logparser']
        response = lambda_client.untag_resource(Resource=event_arn,TagKeys=['count_stepFail_logparser'])
    elif: emr_name == 'logprocessor':
        count = tag_response['Tags']['count_stepFail_logprocessor']
        response = lambda_client.untag_resource(Resource=event_arn,TagKeys=['count_stepFail_logprocessor'])
    else:
        return "ERROR INPUT"
    
    count = int(count)
    count += 1
    
    send_email = 0
    
    
    if count <= 4:
        if emr_name == 'logparser':
            response = lambda_client.tag_resource(Resource=event_arn,Tags={'count_stepFail_logparser': str(count)})
        elif: emr_name == 'logprocessor':
            response = lambda_client.tag_resource(Resource=event_arn,Tags={'count_stepFail_logprocessor': str(count)})
            
    else:
        send_email = 1
        if emr_name == 'logparser':
            response = lambda_client.tag_resource(Resource=event_arn,Tags={'count_stepFail_logparser': '0'})
            response = events_client.disable_rule(Name=os.environ['rule_name_logparser'])
        elif: emr_name == 'logprocessor':
            response = lambda_client.tag_resource(Resource=event_arn,Tags={'count_stepFail_logprocessor': '0'})
            response = events_client.disable_rule(Name=os.environ['rule_name_logprocessor'])
        
    if send_email == 1:
        
        destination_emails = os.environ['destination_emails']
        destination_emails = destination_emails.split(',')
        
        charset = "UTF-8"
        
        body_text = (emr_name+" EMR not working")
        
        body_html = """<html><head></head><body>
        <h1>EMR STEP ERROR</h1>
        <p>EMR not working. Check for STEP error!</p>
        </body></html>"""
        
        try:
            response = ses_client.send_email(
                Source=os.environ['sender'],
                Destination={
                    'ToAddresses': 
                        destination_emails,
                },
                Message={
                    'Subject': {
                        'Data': os.environ['subject'],
                        'Charset' : charset
                    },
                    'Body': {
                        'Text': {
                            'Data': body_text,
                            'Charset': charset
                        },
                        'Html': {
                            'Data': body_html,
                            'Charset': charset
                        },
                    }
                }
            )
        
        except ClientError as e:
            print(e.response['Error']['Message'])