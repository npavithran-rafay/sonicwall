import json, os, boto3
from datetime import datetime, timedelta
import time

region = os.environ['region']

ddb_client = boto3.client('dynamodb', region)
sns_client = boto3.client('sns', region)

def lambda_handler(event, context):
    seconds = time.time()
    epoch_now = int(seconds)
    epoch_now = epoch_now - (epoch_now % 3600)
    epoch_before = epoch_now - 3600
    epoch_day_minus = epoch_now - 86400
    
    now = datetime.now()
    hour_now = now.strftime("%H")
    
    # ReadKinesisData
    try:
        response = ddb_client.scan(TableName=os.environ['DDBtablename_Kinesis'],
            ScanFilter={
                'ts': {
                    'AttributeValueList': [
                        {
                            'S': str(epoch_now)
                        }
                    ],
                    'ComparisonOperator': 'LE'
                },
                'ts': {
                    'AttributeValueList': [
                        {
                            'S': str(epoch_before)
                        }
                    ],
                    'ComparisonOperator': 'GE'
                }
            }
        )
        
        count = 0
        limit = len(response['Items'])/2
        
        for records in response['Items']:
            if records['GetRecords_IteratorAgeMilliseconds']['S'] > '0.0':
                count += 1

        if count >= limit:
            try:
                response = sns_client.publish(
                    TopicArn=os.environ['topicARN'],
                    Message='{}'.format(response['Items']),
                    Subject='ALARM: Kinesis IteratorAgeMilliseconds ALERT!')
            except:
                print("Couldn't email Kinesis response")
            
    except:
        print("ERROR: Couldn't Scan")
    
    if hour_now == "00":
        try:
            response = ddb_client.scan(TableName=os.environ['DDBtablename_RedShift'],
                ScanFilter={
                    'ts': {
                        'AttributeValueList': [
                            {
                                'S': str(epoch_now)
                            }
                        ],
                        'ComparisonOperator': 'LE'
                    },
                    'ts': {
                        'AttributeValueList': [
                            {
                                'S': str(epoch_day_minus)
                            }
                        ],
                        'ComparisonOperator': 'GE'
                    }
                }
            )
            
            try:
                response = sns_client.publish(
                    TopicArn=os.environ['topicARN'],
                    Message='{}'.format(response['Items']),
                    Subject='Daily Update: RedShift Data Monitoring')
            except:
                print("Couldn't email RedShift response")
        
        except:
            print("ERROR: Cannot retreive RedShift data")
