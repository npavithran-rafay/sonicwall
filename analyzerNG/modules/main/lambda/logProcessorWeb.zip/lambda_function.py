import boto3,json,os
from datetime import datetime

region=os.environ['region']
emr_client = boto3.client('emr',region)
lambda_client = boto3.client('lambda',region)
s3_resource = boto3.resource('s3',region)
s3_client = boto3.client('s3',region)
events_client = boto3.client('events',region)
dynamo_client = boto3.client('dynamodb',region)
    
connection = boto3.client('emr',region)

def create_eventBridge(cloudwatch_rule_name,cluster_id,dynamo_tables,new_cluster_id):
    #Remove Existing Rule
    try:
        event_response = events_client.describe_rule(Name=cloudwatch_rule_name)
        
        event_arn = lambda_client.get_function(FunctionName=os.environ['lambda_name'])
        event_arn = event_arn['Configuration']['FunctionArn']
        
        try:
            response = events_client.list_targets_by_rule(Rule=event_response['Name'])
            response = events_client.remove_targets(Rule=event_response['Name'],Ids=[response['Targets'][0]['Id']])
        except:
            print("No targets to remove from rule")
        response = events_client.delete_rule(Name=event_response['Name'])
    except:
        print('Error modifying EventBridge rule. Will create new rule.')
    
    event_pattern="{\"source\":[\"aws.emr\"],\"detail-type\":[\"EMR Cluster State Change\"],\"detail\":{\"state\":[\"RUNNING\"],\"clusterId\":[\""+new_cluster_id+"\"]}}"
    try:
        response = events_client.put_rule(Name=cloudwatch_rule_name,EventPattern=event_pattern,State='ENABLED')
    except:
        print("Error creating rule")
        
    ConstantJSON = "{     \"command\":\"reset_ddb_emr\",     \"emr_cluster_id\":\""+cluster_id+"\",     \"dynamo_tables\":\""+dynamo_tables+"\",     \"cloudwatch_rule_name\":\""+cloudwatch_rule_name+"\" }"
    
    try:
        event_response = events_client.describe_rule(Name=cloudwatch_rule_name)
        event_arn = lambda_client.get_function(FunctionName=os.environ['lambda_name'])
        event_arn = event_arn['Configuration']['FunctionArn']
        response = events_client.put_targets(Rule=cloudwatch_rule_name,Targets=[{'Id': '1','Arn': event_arn,'Input':ConstantJSON},])
    except:
        print("Error adding target") 
        

def start_new_emr(cluster_ids_old):
    
    bucket_name = os.environ['bucket_name']
    config_filename = os.environ['config_filename']
    
    result = s3_client.get_object(Bucket=bucket_name, Key=config_filename) 
    text = result["Body"].read().decode()
    json_data = json.loads(text)
    
    step_command=[]
    for key, value in json_data['common'].items():
        step_command.append(key)
        step_command.append(value)
    for key, value in json_data['logProcessorWeb'].items():
        if key == '--conf':
            for i in value:
                step_command.append(key)
                step_command.append(i)
           
        else:
            step_command.append(key)
            step_command.append(value)   
    #We are trying to remove the key for the last item where we call the jar: 'jar_file_location'
    del step_command[-2]
    
    step_function_argument = ['spark-submit']
    step_function_argument+=step_command
    
    #Running the EMR Cluster

    cluster_id = emr_client.run_job_flow(
        Name=json_data['logProcessorWebEmrDetails']['Name'],
        LogUri='s3://'+bucket_name+'/logs/',
        ReleaseLabel=json_data['logProcessorWebEmrDetails']['ReleaseLabel'],
        Applications=json_data['logProcessorWebEmrDetails']['Applications'],
        VisibleToAllUsers=True,
        JobFlowRole=json_data['logProcessorWebEmrDetails']['JobFlowRole'],
        ServiceRole=json_data['logProcessorWebEmrDetails']['ServiceRole'],
        ScaleDownBehavior=json_data['logProcessorWebEmrDetails']['ScaleDownBehavior'],
        EbsRootVolumeSize=json_data['logProcessorWebEmrDetails']['EbsRootVolumeSize'],
        Tags=json_data['logProcessorTags'],
        StepConcurrencyLevel=2,
        Instances=json_data['logProcessorInstances']['Instances'],
        Steps = [
            {
                'Name': 'Setup Hadoop Debugging',
                'ActionOnFailure': 'TERMINATE_CLUSTER',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                'Args': ['state-pusher-script']
                }
            },
            {
                'Name': 'logProcessorWeb-jar-step',
                'ActionOnFailure': 'CONTINUE',
                'HadoopJarStep': {
                    'Jar': 'command-runner.jar',
                    'Args': step_function_argument
                }
            }
        ]
    )
    
    new_cluster_id=cluster_id['JobFlowId']
    
    if json_data['logProcessorManagedScalingPolicy']['autoscalingFlag']=='on':
        Cluster_ID=new_cluster_id
        response = emr_client.put_managed_scaling_policy(
            ClusterId=Cluster_ID,
            ManagedScalingPolicy={'ComputeLimits': json_data['logProcessorManagedScalingPolicy']['ComputeLimits']}
        )
    
    print ('Cluster id: ', new_cluster_id)
    
    dynamo_tables=""
    for i in json_data['logProcessorWebDynamoDBTables']:
        dynamo_tables=dynamo_tables+i+"="
    dynamo_tables=dynamo_tables[:-1]
    
    try:
        create_eventBridge(os.environ['cloudWatch_ruleName_logProcessor'],cluster_ids_old,dynamo_tables,new_cluster_id)
    except:
        print("Error deleting the old logProcessor and removing table data")

def lambda_handler(event, context):
    # TODO implement
    
    command = event['command']
    
    if command == 'restart':
        
        emr_cluster_name=event['emr_cluster_restart_name']
        lambda_name=event['lambda_function_name']
    
        new_run_response=''
        clusterid=''
    
        try:
            running_clusters = emr_client.list_clusters(ClusterStates=['RUNNING','STARTING'])
            for i in range(len(running_clusters['Clusters'])):
                if running_clusters['Clusters'][i]['Name']==emr_cluster_name:
                    clusterid=running_clusters['Clusters'][i]['Id']
        except:
            clusterid=''
        
        if clusterid!='':
            try:
                emrcluster=emr_client.describe_cluster(ClusterId=clusterid)
                emrcluster_readytime=emrcluster['Cluster']['Status']['Timeline']['ReadyDateTime'].replace(tzinfo=None)
                time_now=datetime.now()
                duration = (time_now - emrcluster_readytime).total_seconds()
                hours = divmod(duration, 3600)[0]
                if int(hours)>=int(os.environ['recreate_freq_hours']):
                    try:
                        print("Terminated")
                        start_new_emr(clusterid)
                        new_run_response = "A new cluster has been started"
                    except:
                        new_run_response = "Error restarting cluster"
                else:
                    print("Not timed out yet")
                
            except:
                print("Cluster hasn't timed out yet")
     
        else:
            start_new_emr('NONE')
    
    
    
    elif command == 'reset_ddb_emr':
        
        cluster_id = event['emr_cluster_id']
        dynamo_tables = event['dynamo_tables']
        eventbridge_rule = event['cloudwatch_rule_name']
        
        #Get tables
        try:
            dynamo_tables=dynamo_tables.split('=')
        except:
            print("Error tables")
                
        #terminate emr cluster
        try:
            response = emr_client.terminate_job_flows(JobFlowIds=[cluster_id])
        except:
            print("Cluster unable to terminate")
        
        '''
        #delete tablem items
        for i in dynamo_tables:
            scan = dynamo_client.scan(TableName=i)
            #primaryKey = list(scan['Items'][0].keys())[0]
            primaryKey = os.environ['DynamoDBPrimaryKey']
            for item in scan['Items']:
                try:
                    response = dynamo_client.delete_item(TableName=i,Key={primaryKey: item[primaryKey]})
                    print(response)
                except:
                    print("Error: Couldn't delete table item {}".format(item))
        '''
        
        for i in dynamo_tables:
            try:
                response = dynamo_client.delete_table(TableName=i)
            except:
                print("Error deleting table")
        
        for i in dynamo_tables:
            table_created = 1
            while table_created:
                try:
                    response = dynamo_client.create_table(AttributeDefinitions=[{'AttributeName': os.environ['DynamoDBPrimaryKey'],'AttributeType': 'S'}],TableName=i,KeySchema=[{'AttributeName': os.environ['DynamoDBPrimaryKey'],'KeyType': 'HASH'}],BillingMode='PAY_PER_REQUEST')
                    table_created = 0
                except:
                    print("Couldn't delete and recreate DDB tables")
    
        
        #disable EventBridge rule
        try:
            response = events_client.disable_rule(Name=eventbridge_rule)
        except:
            print("Error disable rule")
        
        return "Task Completed"
    
    else:
        
        return "COMMAND ERROR"