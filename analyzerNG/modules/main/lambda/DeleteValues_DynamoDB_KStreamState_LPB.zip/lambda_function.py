import json, boto3, os, csv, time, ast
#from boto3.dynamodb.conditions import Key, Attrimport

def lambda_handler(event, context):
    # TODO implement
    region = os.environ['region']
    dynamodb = boto3.resource('dynamodb', region)
    table_name = os.environ['DDBStreamName']
    table = dynamodb.Table(table_name)
    
    for i in ['flowbytime-bucket-partindex-value','flowurlbytime-bucket-partindex-value']:
        response = table.delete_item(
            Key={
                'streamName': i
            }
        )
        print(response)