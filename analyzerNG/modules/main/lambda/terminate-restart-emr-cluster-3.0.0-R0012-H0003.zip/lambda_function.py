import boto3,json,os
from datetime import datetime

def lambda_handler(event, context):
    # TODO implement
    emr_cluster_name=event['emr_cluster_restart_name']
    lambda_name=event['lambda_function_name']
    emr_client = boto3.client('emr',os.environ['region'])
    lambda_client = boto3.client('lambda',os.environ['region'])
    s3_resource = boto3.resource('s3',os.environ['region'])
    new_run_response=''
    clusterid=''
    
    try:
        running_clusters = emr_client.list_clusters(ClusterStates=['RUNNING','STARTING'])
        for i in range(len(running_clusters['Clusters'])):
            if running_clusters['Clusters'][i]['Name']==emr_cluster_name:
                clusterid=running_clusters['Clusters'][i]['Id']
    except:
        clusterid=''
        
    if clusterid!='':
        try:
            emrcluster=emr_client.describe_cluster(ClusterId=clusterid)
            emrcluster_readytime=emrcluster['Cluster']['Status']['Timeline']['ReadyDateTime'].replace(tzinfo=None)
            time_now=datetime.now()
            duration = (time_now - emrcluster_readytime).total_seconds()
            hours = divmod(duration, 3600)[0]
            if int(hours)>=int(os.environ['recreate_freq_hours']):
                try:
                    #emr_client.terminate_job_flows(JobFlowIds=[clusterid])
                    print("Terminated")
                    try:
                        event_arn = lambda_client.get_function(FunctionName=lambda_name)
                        event_arn = event_arn['Configuration']['FunctionArn']
                        response = lambda_client.untag_resource(Resource=event_arn,TagKeys=['cluster_id'])
                        response = lambda_client.tag_resource(Resource=event_arn,Tags={'cluster_id': clusterid})
                    except:
                        print("can't utag/tag resource")
                    
                    
                    lambda_client.invoke(FunctionName=lambda_name)
                    new_run_response = "A new cluster has been started"
                except:
                    new_run_response = "Error restarting cluster"
            else:
                print("Not timed out yet")
            
        except:
            print("Cluster hasn't timed out yet")
   
    else:
        try:
            lambda_client.invoke(FunctionName=lambda_name)
            new_run_response = "No emr clusters were running but a new a cluster has been started"
        except:
            print("Error invoking new cluster")