import boto3,psycopg2, os, sys, json, time
from datetime import datetime

connection = boto3.client('emr',region_name=os.environ['region'])
s3 = boto3.resource('s3')
s3_client = boto3.client('s3')
    
#Reading Config JSON file to get the step commands
    
bucket_name = os.environ['bucket_name']
config_filename = os.environ['config_filename']
result = s3_client.get_object(Bucket=bucket_name, Key=config_filename) 
text = result["Body"].read().decode()
json_data = json.loads(text)

REDSHIFT_DATABASE = json_data['cronJobConfig']['REDSHIFT_DATABASE']
REDSHIFT_USER = json_data['cronJobConfig']['REDSHIFT_USER']
REDSHIFT_PASSWD = json_data['cronJobConfig']['REDSHIFT_PASSWD']
REDSHIFT_PORT = json_data['cronJobConfig']['REDSHIFT_PORT']
REDSHIFT_ENDPOINT = json_data['cronJobConfig']['REDSHIFT_ENDPOINT']

__CREATE_STMT = """
CREATE TABLE IF NOT EXISTS flowdata_{} (
"timestamp" int8 encode az64,
"id" int8 encode az64 not null default '0',
"slot_id" int8 encode az64 not null default '0',
"init_gw_mac" CHAR(17) encode zstd,
"resp_gw_mac" CHAR(17) encode zstd,
"init_addr" int8 encode az64 not null default '0',
"init_loc_id" int encode az64 not null default '0',
"resp_addr" int8 encode az64 not null default '0',
"resp_loc_id" int encode az64 not null default '0',
"init_remap_ip" int8 encode az64 not null default '0',
"resp_remap_ip" int8 encode az64 not null default '0',
"init_gw" int8 encode az64 not null default '0',
"resp_gw" int8 encode az64 not null default '0',
"init_iface" int encode az64 not null default '0',
"resp_iface" int encode az64 not null default '0',
"init_port" int encode az64 not null default '0',
"resp_port" int encode az64 not null default '0',
"init_remap_port" int encode az64 not null default '0',
"resp_remap_port" int encode az64 not null default '0',
"init_pkts" int8 encode az64 not null default '0',
"init_octets" int8 encode az64 not null default '0',
"resp_pkts" int8 encode az64 not null default '0',
"resp_octets" int8 encode az64 not null default '0',
"last_timestamp" int8 encode raw,
"flags" int2 encode az64,
"protocol" varchar encode zstd not null default 'NA',
"b_reason" int2 encode az64 not null default '0',
"botnet" int2 encode az64 not null default '0',
"sig_id" int encode az64 not null default '0',
"gapp_id" varchar encode zstd,
"intrusion_id" int encode az64 not null default '0',
"gintrusion_id" varchar encode zstd,
"gav_id" int encode az64 not null default '0',
"ggav_id" varchar encode zstd,
"aspy_id" int encode az64 not null default '0',
"gaspy_id" varchar encode zstd,
"is_close" int2 encode az64,
"is_url" int2 encode az64,
"dpissl" int2 encode az64,
"state" int2 encode az64,
"user_auth" int encode az64,
"country_id" int encode az64 not null default '0',
"security_policy_id" bigint encode az64 not null default '0',
"app_rule_id" int encode az64 not null default '0',
"nat_policy_id" int encode az64 not null default '0',
"route_policy_id" int encode az64 not null default '0',
"decryption_policy_id" int encode az64 not null default '0',
"init_tos" int encode az64 not null default '0',
"resp_tos" int encode az64 not null default '0',
"init_vpn_policy_name" varchar encode zstd not null DEFAULT 'NA',
"resp_vpn_policy_name" varchar encode zstd not null default 'NA',
"usr_name" varchar encode zstd not null default 'NA',
"gapp_sig_ids_1" varchar encode zstd,
"gapp_sig_ids_2" varchar encode zstd,
"gapp_sig_ids_3" varchar encode zstd,
"gapp_sig_ids_4" varchar encode zstd,
"gintrusion_sig_ids_1" varchar encode zstd,
"gintrusion_sig_ids_2" varchar encode zstd,
"gintrusion_sig_ids_3" varchar encode zstd,
"gintrusion_sig_ids_4" varchar encode zstd,
"app_id" int encode az64 not null default '0',
"risk" int encode az64 not null default '0',
"in_pri" int encode az64 not null default '0',
"out_pri" int encode az64 not null default '0',
"app_name" varchar encode zstd not null default 'NA',
"cat_id" int encode az64 not null default '0',
"sig_name" varchar encode zstd not null default 'NA',
"intrusion_name" varchar encode zstd not null default 'NA',
"aspy_name" varchar encode zstd not null default 'NA',
"gav_name" varchar encode zstd not null default 'NA',
"tenantid" varchar encode zstd not null default 'NA',
"groupid" varchar encode zstd not null default 'NA',
"decryption_ssl_id" int encode az64 not null default '0',
"decryption_ssh_id" int encode az64 not null default '0',
"sdwan" int encode az64 not null default '0', 
"threat_id" int encode az64 not null default '0', 
"threat_type" varchar encode zstd not null default 'NA',
"threat_name" varchar encode zstd not null default 'NA',
"prio_id" int encode az64,
"aspy_priority" int encode az64,
"gav_priority" int encode az64,
"serialnum" CHAR(12) encode raw
) SORTKEY(last_timestamp)
"""

__CREATE_STMT_URL = """
CREATE TABLE IF NOT EXISTS flowurl_{} (
"timestamp" int8 encode az64,
"id" int8 encode az64 not null default '0',
"slot_id" int8 encode az64 not null default '0',
"init_gw_mac" CHAR(17) encode zstd,
"resp_gw_mac" CHAR(17) encode zstd,
"init_addr" int8 encode az64 not null default '0',
"init_loc_id" int encode az64 not null default '0',
"resp_addr" int8 encode az64 not null default '0',
"resp_loc_id" int encode az64 not null default '0',
"init_remap_ip" int8 encode az64 not null default '0',
"resp_remap_ip" int8 encode az64 not null default '0',
"init_gw" int8 encode az64 not null default '0',
"resp_gw" int8 encode az64 not null default '0',
"init_iface" int encode az64 not null default '0',
"resp_iface" int encode az64 not null default '0',
"init_port" int encode az64 not null default '0',
"resp_port" int encode az64 not null default '0',
"init_remap_port" int encode az64 not null default '0',
"resp_remap_port" int encode az64 not null default '0',
"init_pkts" int8 encode az64 not null default '0',
"init_octets" int8 encode az64 not null default '0',
"resp_pkts" int8 encode az64 not null default '0',
"resp_octets" int8 encode az64 not null default '0',
"last_timestamp" int8 encode raw,
"flags" int2 encode az64,
"protocol" varchar encode zstd not null default 'NA',
"b_reason" int2 encode az64 not null default '0',
"botnet" int2 encode az64 not null default '0',
"sig_id" int encode az64 not null default '0',
"gapp_id" varchar encode zstd,
"intrusion_id" int encode az64 not null default '0',
"gintrusion_id" varchar encode zstd,
"gav_id" int encode az64 not null default '0',
"ggav_id" varchar encode zstd,
"aspy_id" int encode az64 not null default '0',
"gaspy_id" varchar encode zstd,
"is_close" int2 encode az64,
"is_url" int2 encode az64,
"dpissl" int2 encode az64,
"state" int2 encode az64,
"user_auth" int encode az64,
"country_id" int encode az64 not null default '0',
"security_policy_id" bigint encode az64 not null default '0',
"app_rule_id" int encode az64 not null default '0',
"nat_policy_id" int encode az64 not null default '0',
"route_policy_id" int encode az64 not null default '0',
"decryption_policy_id" int encode az64 not null default '0',
"init_tos" int encode az64 not null default '0',
"resp_tos" int encode az64 not null default '0',
"init_vpn_policy_name" varchar encode zstd not null DEFAULT 'NA',
"resp_vpn_policy_name" varchar encode zstd not null default 'NA',
"usr_name" varchar encode zstd not null default 'NA',
"gapp_sig_ids_1" varchar encode zstd,
"gapp_sig_ids_2" varchar encode zstd,
"gapp_sig_ids_3" varchar encode zstd,
"gapp_sig_ids_4" varchar encode zstd,
"gintrusion_sig_ids_1" varchar encode zstd,
"gintrusion_sig_ids_2" varchar encode zstd,
"gintrusion_sig_ids_3" varchar encode zstd,
"gintrusion_sig_ids_4" varchar encode zstd,
"urltime" int8 encode az64 not null default '0',
"domain" varchar encode zstd not null DEFAULT 'NA',
"ip" int8 encode az64 not null default '0',
"rating1" int encode az64 not null default '0',
"rating2" int encode az64 not null default '0',
"rating3" int encode az64 not null default '0',
"rating4" int encode az64 not null default '0',
"app_id" int encode az64 not null default '0',
"risk" int encode az64 not null default '0',
"in_pri" int encode az64 not null default '0',
"out_pri" int encode az64 not null default '0',
"app_name" varchar encode zstd not null default 'NA',
"cat_id" int encode az64 not null default '0',
"sig_name" varchar encode zstd not null default 'NA',
"intrusion_name" varchar encode zstd not null default 'NA',
"aspy_name" varchar encode zstd not null default 'NA',
"gav_name" varchar encode zstd not null default 'NA',
"tenantid" varchar encode zstd not null default 'NA',
"groupid" varchar encode zstd not null default 'NA',
"decryption_ssl_id" int encode az64 not null default '0',
"decryption_ssh_id" int encode az64 not null default '0',
"sdwan" int encode az64 not null default '0', 
"threat_id" int encode az64 not null default '0', 
"threat_type" varchar encode zstd not null default 'NA',
"threat_name" varchar encode zstd not null default 'NA',
"prio_id" int encode az64,
"aspy_priority" int encode az64,
"gav_priority" int encode az64,
"serialnum" CHAR(12) encode raw
) SORTKEY(last_timestamp);
"""


def ts_to_date(ts):
        date = datetime.utcfromtimestamp(ts)
        return '{}_{}_{}'.format(date.year, date.month, date.day)

def drop_achived_flowdata_tables():
        _s = time.time() + 3600
        table_suffix_1 = ts_to_date(_s)
        table_suffix_2 = ts_to_date(_s - (1 * 24 * 3600))
        REDSHIFT_QUERY = "SELECT tablename FROM pg_catalog.pg_tables where schemaname='public' and (tablename like 'flowdata_%' OR tablename like 'flowurl_%') AND tablename != 'flowdata_alerts'  AND {} AND {};".format(
                        ' AND '.join(map(lambda x: 'tablename != \'flowdata_{}\''.format( ts_to_date(_s - (x * 24 * 3600))), range(7))),
                        ' AND '.join(map(lambda x: 'tablename != \'flowurl_{}\''.format( ts_to_date(_s - (x * 24 * 3600))), range(7)))
                        )
        #print(REDSHIFT_QUERY)
        try:
                conn = psycopg2.connect(
                        dbname=REDSHIFT_DATABASE,
                        user=REDSHIFT_USER,
                        password=REDSHIFT_PASSWD,
                        port=REDSHIFT_PORT,
                        host=REDSHIFT_ENDPOINT)
        except Exception as e:
                print("Connection Issue: " + str(e))
        '''
        try:
                cursor = conn.cursor()
                cursor.execute(REDSHIFT_QUERY)
                records = cursor.fetchall()
                tables = map(lambda x: x[0], records)
                print(tables)
                for table in tables:
                        DROP_QUERY = 'DROP TABLE public.{}'.format(table)
                        cursor.execute(DROP_QUERY)
                        conn.commit()
                        print('table {} dropped.'.format(table))
                _s = time.time()
                VACUUM_QUERY = 'END TRANSACTION; VACUUM SORT ONLY public.flowdata_{};'.format(table_suffix_2)
                cursor.execute(VACUUM_QUERY)
                conn.commit()
                print('VACCUM done in {} seconds'.format(time.time() - _s))
                cursor.close()
                conn.close()
        except Exception as e:
                print("Execution Issue: " + str(e))
        '''



def create_flowdata_new_table():

        try:
                conn = psycopg2.connect(
                        dbname=REDSHIFT_DATABASE,
                        user=REDSHIFT_USER,
                        password=REDSHIFT_PASSWD,
                        port=REDSHIFT_PORT,
                        host=REDSHIFT_ENDPOINT)
        except Exception as e:
                print("Connection Issue: " + str(e))
        try:
                cursor = conn.cursor()
                cursor.execute('select groname from pg_group;')
                groupNames = cursor.fetchall()
                print(groupNames)
                groupNames = [item for tup in groupNames for item in tup]
                if 'load' not in groupNames:
                        cursor.execute('CREATE GROUP load;')
                        conn.commit()
                else:
                        print("GROUP load exists")
                if 'transform' not in groupNames:
                        cursor.execute('CREATE GROUP transform;')
                        conn.commit()
                else:
                        print("GROUP transform exists")
                if 'ad_hoc' not in groupNames:
                        cursor.execute('CREATE GROUP ad_hoc;')
                        conn.commit()
                else:
                        print("GROUP ad_hoc exists")
                        
                cursor.execute('select usename from pg_user;')
                userNames = cursor.fetchall()
                userNames = [item for tup in userNames for item in tup]
                if 'flowloader' not in userNames:
                        cursor.execute('CREATE USER flowloader PASSWORD {};'.format(json_data['cronJobConfig']['REDSHIFT_PASSWD']))
                        cursor.execute('ALTER GROUP load ADD USER flowloader;')
                        cursor.execute('GRANT USAGE ON SCHEMA public TO flowloader;')
                        conn.commit()
                if 'flowreader' not in userNames:
                        cursor.execute('CREATE USER flowreader PASSWORD {};'.format(json_data['cronJobConfig']['REDSHIFT_PASSWD']))
                        cursor.execute('ALTER GROUP ad_hoc ADD USER flowreader;')
                        cursor.execute('GRANT USAGE ON SCHEMA public TO flowreader;')
                        conn.commit()
                conn.commit()
                cursor.close()
                '''       
                CREATE GROUP load;
                CREATE GROUP transform;
                CREATE GROUP ad_hoc;
                CREATE USER flowloader PASSWORD 'AWSPassword1234';
                ALTER GROUP load ADD USER flowloader;
                CREATE USER flowreader PASSWORD 'AWSPassword1234';
                ALTER GROUP ad_hoc ADD USER flowreader;
                '''
                
                for i in range(7):
                        _s = time.time() + 3600 - (i * 86400)
                        table_suffix = '_'.join(ts_to_date(_s).split('_')[:3])
                        REDSHIFT_QUERY = __CREATE_STMT.format(table_suffix)
                        REDSHIFT_QUERY_URL = __CREATE_STMT_URL.format(table_suffix)
                        #print(REDSHIFT_QUERY)
                        #print(REDSHIFT_QUERY_URL)
                        cursor = conn.cursor()
                        cursor.execute(REDSHIFT_QUERY)
                        conn.commit()
                        cursor.execute(REDSHIFT_QUERY_URL)
                        conn.commit()
                cursor.execute('GRANT ALL ON ALL TABLES IN SCHEMA public TO flowloader;')
                cursor.execute('GRANT SELECT ON ALL TABLES IN SCHEMA public TO flowreader;')
                conn.commit()
                cursor.close()
                conn.close()
                print('created new table :: flowdata_{}'.format(table_suffix))
        except Exception as e:
                print("Execution Issue: " + str(e))

'''
def vacuum_current_table():
        _s = time.time()
        table_suffix = '_'.join(ts_to_date(_s).split('_')[:3])
        try:
                conn = psycopg2.connect(
                        dbname=REDSHIFT_DATABASE,
                        user=REDSHIFT_USER,
                        password=REDSHIFT_PASSWD,
                        port=REDSHIFT_PORT,
                        host=REDSHIFT_ENDPOINT)
        except Exception as e:
                print("Connection Issue: " + str(e))
        try:
                VACUUM_QUERY = 'END TRANSACTION; set analyze_threshold_percent to 0; VACUUM SORT ONLY public.flowdata_{}; ANALYZE public.flowdata_{}'.format(table_suffix, table_suffix)
                cursor = conn.cursor()
                cursor.execute(VACUUM_QUERY)
                conn.commit()
                cursor.close()
                conn.close()
                print('vacuumed table :: flowdata_{}'.format(table_suffix))
        except Exception as e:
                print("Execution Issue: " + str(e))
'''

def lambda_handler(event, context):
        
        table_type = event['command']
        
        if table_type=='flow':
                drop_achived_flowdata_tables()
                create_flowdata_new_table()
        else:
                print('unknown type')
        '''
        elif table_type=='flow-c':
                vacuum_current_table()
        '''
        
