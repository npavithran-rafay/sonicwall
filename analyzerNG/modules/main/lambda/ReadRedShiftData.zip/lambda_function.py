import json, os, boto3
from datetime import datetime, timedelta

region = os.environ['region']

def add_value_to_DDB(ts,item,itemColName):
    
    dynamodb = boto3.resource('dynamodb', region)
    table = dynamodb.Table(os.environ['DDBtablename'])
    
    try:
        response = table.update_item(
            Key={
                'ts': ts
            },
            UpdateExpression="set {}=:a".format(itemColName),
            ExpressionAttributeValues={
                ':a': item
            }
        )
    except:
        print("Couldn't update table with {} - {}:{}".format(ts,itemColName,item))
    

def lambda_handler(event, context):
    ddb_client = boto3.client('dynamodb', region)
    try:
        response = ddb_client.create_table(
            AttributeDefinitions=[{'AttributeName': 'ts','AttributeType': 'S'}],
            TableName=os.environ['DDBtablename'],
            KeySchema=[{'AttributeName': 'ts','KeyType': 'HASH'}],
            ProvisionedThroughput={'ReadCapacityUnits': 5,'WriteCapacityUnits': 5}
            )
    except:
        print("Table already exists")
    
    dynamodb = boto3.resource('dynamodb', region)
    table = dynamodb.Table(os.environ['DDBtablename'])
    redshift_client = boto3.client('redshift', region)
    cloudwatch_client = boto3.client('cloudwatch', region)
    
    CPUUtilization = []
    PercentageDiskSpaceUsed = []
    DatabaseConnections = []
    WriteThroughput = []
    ReadThroughput = []
    total = []
    
    response = cloudwatch_client.list_metrics(Namespace='AWS/Redshift', RecentlyActive='PT3H')
    
    
    for i in response['Metrics']:
        for j in range(1):
            try:
                if i['Dimensions'][1]['Value'] == os.environ['redshift_cluster']:
                    #print(i)
                    #if i['MetricName'] == 'ReadThroughput':
                    #    print(i)
                    
                    if i['MetricName'] == 'CPUUtilization':
                        CPUUtilization.append(i)
                    if i['MetricName'] == 'PercentageDiskSpaceUsed':
                        PercentageDiskSpaceUsed.append(i)
                    if i['MetricName'] == 'DatabaseConnections':
                        DatabaseConnections.append(i)
                    if i['MetricName'] == 'WriteThroughput':
                        WriteThroughput.append(i)
                    if i['MetricName'] == 'ReadThroughput':
                        ReadThroughput.append(i)
                
            except:
                error = 'Nothing'
    
    timenow = datetime.now()
    timeafter = timedelta(minutes=15)
    timestamps = {}
    
    GRR_response = {}
    GRB_response = {}
    IAM_response = {}
    PRR_response = {}
    PRB_response = {}
    
    
    # GetRecords.Bytes
    
    for i in CPUUtilization:
        GRB_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Average'],
            Unit='Percent'
        )
    
    for i in range(len(GRB_response['Datapoints'])):
        ts = str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp()))
        try:
            response = table.put_item(Item={'ts': ts})
        except:
            print("Couldn't update table with {}".format(ts))
    
        
    for i in range(len(GRB_response['Datapoints'])):
        add_value_to_DDB(str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp())),str(GRB_response['Datapoints'][i]['Average']),'CPUUtilization')
        total.append(str(int(GRB_response['Datapoints'][i]['Timestamp'].timestamp())))
    
    
    # GetRecords.Records
    
    for i in WriteThroughput:
        GRR_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Average']
        )
    
    for i in range(len(GRR_response['Datapoints'])):
        add_value_to_DDB(str(int(GRR_response['Datapoints'][i]['Timestamp'].timestamp())),str(GRR_response['Datapoints'][i]['Average']),'WriteThroughput')
   
        
    # GetRecords.IteratorAgeMilliseconds

    for i in PercentageDiskSpaceUsed:
        IAM_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Average'],
            Unit='Percent'
        )
        
    for i in range(len(IAM_response['Datapoints'])):
        add_value_to_DDB(str(int(IAM_response['Datapoints'][i]['Timestamp'].timestamp())),str(IAM_response['Datapoints'][i]['Average']),'PercentageDiskSpaceUsed')
        
        
    # PutRecords.Bytes
    
    for i in ReadThroughput:
        PRB_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Average']
        )
        
    for i in range(len(PRB_response['Datapoints'])):
        add_value_to_DDB(str(int(PRB_response['Datapoints'][i]['Timestamp'].timestamp())),str(PRB_response['Datapoints'][i]['Average']),'ReadThroughput')
        
        
    # PutRecords.Records
    
    for i in DatabaseConnections:
        PRR_response = cloudwatch_client.get_metric_statistics(
            Namespace=i['Namespace'],
            MetricName=i['MetricName'],
            Dimensions = i['Dimensions'],
            StartTime=timenow - timeafter,
            EndTime=timenow,
            Period=300,
            Statistics=['Average']
        )
    
    for i in range(len(PRR_response['Datapoints'])):
        add_value_to_DDB(str(int(PRR_response['Datapoints'][i]['Timestamp'].timestamp())),str(PRR_response['Datapoints'][i]['Average']),'DatabaseConnections')
    
    print(total)
    return "Task Completed"